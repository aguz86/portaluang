const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  page.on('console', msg => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', error => console.log('PAGE ERROR:', error.message));

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle2' });
  const content = await page.content();
  console.log("Root content contains HTML:", content.includes('AuraLedger'));
  console.log("Root content contains Error:", content.includes('Application Error'));
  
  await browser.close();
})();
